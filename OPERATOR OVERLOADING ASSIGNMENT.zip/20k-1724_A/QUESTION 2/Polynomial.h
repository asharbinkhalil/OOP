/*
 * Polynomial.h
 *
 *  Created on: Nov 14, 2021
 *      Author: asharbinkhalil
 */
#ifndef Polynomial_H_
#define Polynomial_H_
#include<iostream>
using namespace std;
#include"Polynomial.h"
#define SIZE 10
class Polynomial
{
private:
     int poly[SIZE] ;
public:
     Polynomial();
     void getPoly();
     void  operator =(Polynomial);
     Polynomial  operator + (Polynomial);
     Polynomial  operator - (Polynomial);
     Polynomial  operator +=(Polynomial);
     Polynomial  operator -=(Polynomial);
     bool  operator ==(Polynomial);
     friend ostream& operator <<(ostream& s,Polynomial& c);
     friend istream& operator >>(istream& s,Polynomial& c);
     void print(int i = 4)
        {
              for  ( ; i >= 0 ; i-- )
              {
                   if         ( i == 0 && poly[i] > 0 )
                   { cout << " +"; cout  <<  poly[i] ;}
                   else if ( i == 0 &&  poly[i] < 0 )
                   { cout << " "; cout   <<  poly[i] ;}
                   else if    (  poly[i] > 0)
                   { cout << " +"; cout  <<  poly[i] << "x^" << i ;}
                   else if (  poly[i] < 0)
                   { cout << " "; cout  <<  poly[i] << "x^" << i ;}
              }
              cout  << endl;
        }
};
#endif /* Polynomial_H_ */
