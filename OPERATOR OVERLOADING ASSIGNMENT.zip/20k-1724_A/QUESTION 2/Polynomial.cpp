/*
 * Polynomial.cpp
 *
 *  Created on: Nov 14, 2021
 *      Author: asharbinkhalil
 */
#include<iostream>
using namespace std;
#include "Polynomial.h"
 Polynomial ::Polynomial()
{
           for (int i=0 ; i<SIZE ; i++)
                poly[i]=0;
}
void Polynomial ::getPoly()
      {
	//polynomial is initialized
            for(int i=4; i>=0 ; i--)
            {
                 cout<<"Enter cofficient x^" <<i<<endl;
                 cin>>poly[i] ;
            }
      }
 void  Polynomial ::operator =(Polynomial p)
 {
	 //assignment one by one
	 for ( int i=0; i<=4; i++ ){
	            poly[i]=p.poly[i] ;
	      }
 }
Polynomial Polynomial :: operator + (Polynomial P2)
{
	//adding coefficients one by one
     Polynomial  temp;
     for ( int i=0 ;i<=4; i++ )
     {
           temp.poly[i]=poly[i] +temp.poly[i] ;
     }
     return temp;
}
Polynomial Polynomial :: operator - (Polynomial P2)
{     Polynomial  temp;
//subtracting coefficients one by one
     for ( int i=0  ; i<=4 ; i++)
     {
           temp.poly[i]=poly[i]-temp.poly[i];
     }
     return temp;
}
bool Polynomial :: operator ==(Polynomial P2 )
		{
	//comparison one by one
     for (int i=0 ; i<=4 ; i++){
           if(poly[i] != P2.poly[i])
                return false;
     }
     return true;
}
Polynomial Polynomial :: operator +=(Polynomial P2 ) {
     Polynomial  temp;
     for  ( int i = 0  ; i <= 4 ; i++ ){
           temp.poly [i]  =  poly[i] +  temp.poly [i] ;
           poly[i] = temp.poly [i];
     }
     return temp;
}
Polynomial Polynomial :: operator -=(Polynomial P2 ) {
     Polynomial  temp;
     for  ( int i = 0  ; i <= 4 ; i++ ){
           temp.poly[i] =poly[i]-temp.poly[i] ;
           poly[i] = temp.poly [i];
     }
     return temp;
}
ostream& operator <<(ostream &s,Polynomial &c)
	{
	//printing of all polynomials by overloading <<
	for  (int i=4; i>=0; i--)
	              {
	                   if ( i == 0 && c.poly[i] > 0 )
	                   { s<< " +"; s  <<  c.poly[i] ;}
	                   else if( i == 0 &&  c.poly[i] < 0 )
	                   { s << " "; s   <<  c.poly[i] ;}
	                   else if    (  c.poly[i] > 0)
	                   { s << " +"; s  <<  c.poly[i] << "x^" << i ;}
	                   else if (  c.poly[i] < 0)
	                   { s << " "; s  <<  c.poly[i] << "x^" << i ;}
	              }
	              s  << endl;
	              return s;
	}
istream& operator >>(istream &s,Polynomial &c)
	{
	//input of polynomials one by one by overloading >>
			for(int i=3  ; i>=0 ; i--)
			       {
			            cout<<"Enter cofficient x^" <<i<<endl;
			            s>>c.poly[i] ;
			        }
	    return s;
	}
