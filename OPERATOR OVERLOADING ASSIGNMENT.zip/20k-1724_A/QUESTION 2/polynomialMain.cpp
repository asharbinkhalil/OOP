//============================================================================
// Name        : assign3q2.cpp
// Author      : ASHAR
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include "Polynomial.h"
#include <iostream>
using namespace std;
int main()
{
     Polynomial P1, P2, P3;
     cout<<"Enter polynomial one\n";
     P1.getPoly();
     cout<<"Enter polynomial two\n";
     P2.getPoly();
     P1.print();
     P2.print();
     cout<<"Function ONE\n";
     if(P1==P2)
     cout <<"Polynomials are same \n";
     else
     cout <<"Polynomials are not same \n";
     cout<<"Function TWO\n";
     P3 = P1 + P2;
     cout <<"Addition + \n";
     P3.print ();
     cout<<"Function THREE\n";
     P3 = P1 - P2;
     cout <<"Subtraction - \n";
     P3.print ();
     cout<<"Function FOUR\n";
     P1+=P2;
     cout <<"Addition with +=    \n";
     P1.print();
     cout<<"Function FIVE\n";
     P1-=P2;
     cout <<"Subtraction with -= \n";
     P1.print();
     cout<<"Function SIX\n";
     P1=P2;
     P1.print();
     cout<<"Function SEVEN\n";
     cout<<"ENTER polynomial one again\n";
     cin>>P1;
     cout<<"Function EIGHT\n";
     cout<<"Newly entered polynommial is updated\n";
     cout<<P1;
     return 0;
}
