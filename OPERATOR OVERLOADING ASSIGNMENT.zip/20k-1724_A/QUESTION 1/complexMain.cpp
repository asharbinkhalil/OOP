/*
 * complexMain.cpp
 *
 *  Created on: Nov 13, 2021
 *      Author: asharbinkhalil
 */

#include"Complex.h"
#include<iostream>
;
int main()
{
	Complex a1(4,9);
	Complex a2(3,6);
	Complex a3;
	cout<<"FUNCTION ONE EQUALITY CHECK\n";
	if(a1==a2)
	cout<<"EQUAL\n";
	cout<<"FUNCTION TWO NOT-EQUALITY CHECK\n";
	if(a1!=a2)
	cout<<"NOT  EQUAL\n";
	cout<<"FUNCTION THREE >> overloading\n";
	cout<<"enter complex nmber real and imaginary part one by one \n";
	cin>>a3;
	a3.print();
	cout<<"FUNCTION FOUR << overloading\n";
	cout<<a3;
	cout<<"Function FIVE \n";
	cout<<"add (+)"<<endl;
	a3=a1+a2;
	a3.print();
	cout<<"Function SIX \n";
	cout<<"sub (-)"<<endl;
	a3=a1-a2;
	a3.print();
	cout<<"Function SEVEN \n";
	cout<<"Multiplication (*)"<<endl;
	a3=a1*a2;
	a3.print();
	cout<<"Function EIGHT \n";
	cout<<"div (/)";
	a3=a2/a1;
	a3.print();
	cout<<"Function NINE \n";
	cout<<"Assignment";
	a3=a1;
	cout<<"Function TEN \n";
	cout<<"equality operator overloading";
	a3.print();
	cout<<"Function ELEVEN\n";
	cout<<"add (+=)="<<endl;
	a1+=a2;
	a1.print();
	//results will be wrong after this beacuse of the update in real and imag caused by +=
	//but functions are correct if placed on higher order or checked individually
	cout<<"Function TWELEVE \n";
	cout<<"sub (-=)"<<endl;
	a1-=a2;
	a1.print();
	cout<<"Function THIRTEEN \n";
	cout<<"Multiplication (*=)"<<endl;
	a1*=a2;
	a1.print();
	cout<<"div (/=)";
	a1/=a2;
	a1.print();
	if(a1<a2)
		cout<<"less than:";
	if(a1>a2)
			cout<<"greater than:";
	return 0;
	}


