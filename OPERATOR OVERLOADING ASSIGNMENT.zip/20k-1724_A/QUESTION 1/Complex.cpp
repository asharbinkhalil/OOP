/*
 * Complex.cpp
 *
 *  Created on: Nov 13, 2021
 *      Author: asharbinkhalil
 */

#include "Complex.h"
#include<iostream>
using namespace std;
Complex::Complex()
		{
			real=0;
			imag=0;
		}
Complex::Complex(int r, int i)
		{
			real=r;
			imag=i;
		}
		int Complex:: getReal()
		{
			return real;
		}
		int Complex::getImg()
		{
			return imag;
		}
		void Complex::setreal(int r)
		{
			real=r;
		}
		void Complex::setimag(int i)
		{
			imag=i;
		}
		void Complex::print()
		{
			cout<<real <<"+"<<imag<<"i"<<endl;
		}
		Complex Complex::operator + (Complex c)
			{
				Complex temp;
				temp.real=real+c.real;
				temp.imag=imag+c.imag;
				return temp;
			}
			Complex Complex::operator - (Complex c)
				{
					Complex temp;
					temp.real=real-c.real;
					temp.imag=imag-c.imag;
					return temp;
				}
				void Complex::operator = (Complex c)
		{
				real=c.real;
				imag=c.imag;
		}

		void Complex::operator += (Complex c)
		{
			real+=c.real;
			imag+=c.imag;
		}
		void Complex::operator -= (Complex c)
		{
			real-=c.real;
			imag-=c.imag;
		}

				Complex Complex::operator * (Complex c)
		{
			Complex temp;
			temp.real=real*c.real-imag*c.imag;
			temp.imag=real*c.imag+imag*c.real;
			return temp;
		}
				void Complex::operator *= (Complex c)
		{
			float a=real*c.real-imag*c.imag;
			float b=real*c.imag+imag*c.real;
			this->real=a;
			this->imag=b;
		}
				Complex Complex::operator / (Complex c)
		{
					int div=(c.real*c.real) + (c.imag*c.imag);
										    Complex tmp;
										    tmp.real=(real*c.real)+(imag*c.imag);
										    tmp.real/=div;
										    tmp.imag=(imag*c.real)-(real*c.imag);
										    tmp.imag/=div;
										    return tmp;
		}
				void Complex::operator /= (Complex c)
		{
			int a=(c.real*c.real+c.imag*c.imag);
			int b=(this->real*c.real+this->imag*c.imag)/a;
			float e=(c.real*c.real + c.imag*c.imag);
			float d=(this->imag*c.real - this->real*c.imag)/e;
			this->real=b;
			this->imag=d;
		}
		bool Complex::operator == (Complex c)
		{
			int a=0;
			if((real==c.real) && (imag == c.imag))
			  a=1;
			else
				a=0;
			return a;
		}
		bool Complex::operator != (Complex c)
		{
			int a=0;
			if((real!=c.real) || (imag != c.imag))
			  a=1;
			else
				a=0;
			return a;
		}

			bool Complex::operator < (Complex c)
			{int a=0;
				if(this->real<c.real && this->imag<c.imag)
					a=1;
				else
					a=0;
				return a;
			}
			bool Complex::operator > (Complex c)
					{int a=0;
						if(this->real>c.real && this->imag>c.imag)
							a=1;
						else
							a=0;
						return a;
					}
	ostream& operator <<(ostream &s,Complex &c)
	{
		s << c.real << "+"<< c.imag << "i"<< endl;

	    return s;
	}
		istream& operator >>(istream &s,Complex &c)
	{
		s >> c.real >> c.imag;
	    return s;
	}
