/*
 * Complex.h
 *
 *  Created on: Nov 13, 2021
 *      Author: asharbinkhalil
 */

#ifndef COMPLEX_H_
#define COMPLEX_H_
#include<iostream>
using namespace std;
class Complex
{
	private:
		int real;
		int imag;
	public:
		Complex();
		Complex(int r, int i);
		int getReal();
		int getImg();
		void setreal(int r);
		void setimag(int i);
		void print();
		friend ostream& operator <<(ostream& s,Complex& c);
		friend istream& operator >>(istream& s,Complex& c);
		void operator = (Complex c);
		Complex operator + (Complex c);
		void operator += (Complex c);
		void operator -= (Complex c);
		Complex operator - (Complex c);
		Complex operator * (Complex c);
		void operator *= (Complex c);
		Complex operator / (Complex c);
		void operator /= (Complex c);
		bool operator == (Complex c);
		bool operator != (Complex c);
		bool operator < (Complex c);
		bool operator > (Complex c);
};

#endif /* COMPLEX_H_ */
