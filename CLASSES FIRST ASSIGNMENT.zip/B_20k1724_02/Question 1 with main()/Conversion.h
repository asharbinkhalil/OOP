/*
 * Conversion.h
 *
 *  Created on: Oct 13, 2021
 *      Author: asharbinkhalil
 */

#ifndef CONVERSION_H_
#define CONVERSION_H_

#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<math.h>
using namespace std;

class Conversion
{
private:
	char * number;
public:
	Conversion(char *lumb) //CONSTRUCTOR
	{
		char * number=new char[15];
		this->number=lumb;
	}
	void setNumber(char *lumb) //SETTER
	{
		char * number=new char[15];
		this->number=lumb;
	}
	void getNumber()   //GETTER
	{
		cout<<number;
	}
int FindBase(char* temp)
{
		int len;
		//FINDING THE LENGTH OF RECIEVED STRING
		for( len=0; temp[len]; len++)
			{}
		int check=1;
		if(check)
		{
		bool a=0;
		for(int i=0; i<len; i++)
		{
			if(temp[i]!='0' && temp[i]!='1')
				a=1;
		}
		if(a==0)
		{
			cout<<"Number is binary:";
		check=0;
		return 2; 
		}
		}
		if(check)
		{
		char hex[]={'A','B','C','D','E','F','a','b','c','d','e','f'};
		for(int i=0; i<len; i++)
		{
			for(int j=0; j<12; j++)
			{
				if(temp[i]==hex[j] && check==1)
				{	check=0;
					return 16;
					break;
				}
			}
		}
		}
		if(check)
		{
		for(int i=0; i<len; i++)
		{
			if(temp[i]>'7' && check==1)
				{cout<<"number is decimal:";
				check=0;
				return 10;
				}}
		}
		if(check)
		{
			cout<<"Number is Octal \n";
			return 8;
		}
	
}
char* toBinary(char* lum)
{
	int num=0,d;
	int r;
	int lenlum;
	//finding the length of recieved string
		for(lenlum=0; lum[lenlum]!='\0'; lenlum++)
			{}
		for(int i=0; lum[i]!='\0'; i++)
			{	
			lenlum--;
	//for octal check
			for(int k=0; lum[k]!='\0'; k++)
				{
					if(lum[k]<='7')
					d=8;
				}
	//for deciamal check
			for(int k=0; lum[k]!='\0'; k++)
				{
					if(lum[k]>'7' && lum[k]<='9')
					d=10;
				}
	//for hexa check
			for(int k=0; lum[k]!='\0'; k++)
				{
					if(lum[k]>'9')
					d=16;
				}
	//for binary check
			bool a=0;
			for(int i=0; lum[i]!='\0'; i++)
				{
					if(lum[i]!='0' && lum[i]!='1')
					a=1;
				}
				if(a==0)
				{
					d=2;
				}
	//converting string to number by multilpying with power to the base function
			if(lum[i] > '7' && lum[i]<='9')
				{
		 			r = (lum[i] - 48);
		 			num+=r*pow(d,lenlum);
				}
		      	 if(lum[i] >= '0' && lum[i] <= '7')
		        	{
		        		r = (lum[i] - 48);
		        		num+=r*pow(d,lenlum);
		        	}
		        if(lum[i] >= 'a' && lum[i] <= 'f')
		        	{
		        	r = (lum[i] - 87);
		        	num+=r*pow(d,lenlum);
		        	}
		      	else if(lum[i] >= 'A' && lum[i] <= 'F')
		      		{
		      		r=( lum[i] - 55);
				num+=r*pow(d,lenlum);}
				}
			if(d==8)
				num+=2;
	long int numb=0,aisy=1,count=0;
	//function for decimal to required conversion
			for(int i=0; num>=1; i++)
				{
				(numb)+=((num%2)*aisy);
				aisy*=10;
				num/=2;
				count++;
				}
	//saving the reqired result in an array now
	char* binary=new char[count];
	count--;
	for(;count>=0; count--)
	{
	binary[count]=(numb%10)+48;
	numb/=10;
	}
	return binary;
}
char* toOctal(char* lum)
{
	
	int r,d,num=0;
		int lenlum;
		for(lenlum=0; lum[lenlum]!='\0'; lenlum++)
		{}
		for(int i=0; lum[i]!='\0'; i++)
		{
			lenlum--;
			for(int k=0; lum[k]!='\0'; k++)
					{
				if(lum[k]<='7')
				d=8;
											}
			for(int k=0; lum[k]!='\0'; k++)
		{
				if(lum[k]>'7' && lum[k]<='9')
				d=10;
		}
			for(int k=0; lum[k]!='\0'; k++)
				{
						if(lum[k]>'9')
						d=16;
				}
			bool a=0;
			for(int i=0; lum[i]!='\0'; i++)
									{
										if(lum[i]!='0' && lum[i]!='1')
											a=1;
									}
									if(a==0)
									{
										d=2;
									}
			 if(lum[i] > '7' && lum[i]<='9')
	{
		 	r = (lum[i] - 48);
		 	num+=r*pow(d,lenlum);
	 }
	        if(lum[i] >= '0' && lum[i] <= '7')
	        {
	        	r = (lum[i] - 48);
	        	num+=r*pow(d,lenlum);
	        }

	        if(lum[i] >= 'a' && lum[i] <= 'f')
	        { r = (lum[i] - 87);
	        num+=r*pow(d,lenlum);}
	      else if(lum[i] >= 'A' && lum[i] <= 'F')
	      {    r =( lum[i] - 55);
			num+=r*pow(d,lenlum);}
		}
					if(d==8)
						num+=2;

	long int numb=0,aisy=1,count=0;
	for(int i=0; num>=1; i++)
	{
	(numb)+=((num%8)*aisy);
	aisy*=10;
	num/=8;
	count++;
	}
	char* octal=new char[count];
	count--;
	for(;count>=0; count--)
	{
	octal[count]=(numb%10)+48;
	numb/=10;
	}
	return octal;
}
char * toDecimal(char *lum)
{
	int r,d,num=0;
			int lenlum;
			for(lenlum=0; lum[lenlum]!='\0'; lenlum++)
			{}
			for(int i=0; lum[i]!='\0'; i++)
			{
				lenlum--;
				for(int k=0; lum[k]!='\0'; k++)

								{
							if(lum[k]<='7')
							d=8;
														}
						for(int k=0; lum[k]!='\0'; k++)
					{
							if(lum[k]>'7' && lum[k]<='9')
							d=10;
					}
						for(int k=0; lum[k]!='\0'; k++)
							{
									if(lum[k]>'9')
									d=16;
							}
						bool a=0;
								for(int i=0; lum[i]!='\0'; i++)
								{
									if(lum[i]!='0' && lum[i]!='1')
										a=1;
								}
								if(a==0)
								{
									d=2;
								}
				  if(lum[i] > '7' && lum[i]<'9')
		{
			 	r = (lum[i] - 48);
			 	num+=r*pow(d,lenlum);
		 }
		        if(lum[i] >= '0' && lum[i] <= '7')
		        {
		        	r = (lum[i] - 48);
		        	num+=r*pow(d,lenlum);
		        }

		        if(lum[i] >= 'a' && lum[i] <= 'f')
		        { r = (lum[i] - 87);
		        num+=r*pow(d,lenlum);}
		      else if(lum[i] >= 'A' && lum[i] <= 'F')
		      {    r =( lum[i] - 55);
				num+=r*pow(d,lenlum);}}
	long int numb=0,aisy=1,count=0;
		for(int i=0; num>=1; i++)
		{
		(numb)+=((num%10)*aisy);
		aisy*=10;
		num/=10;
		count++;
		}
		char* decimal=new char[count];
		count--;
		for(;count>=0; count--)
		{
		decimal[count]=(numb%10)+48;
		numb/=10;
		}
		return decimal;

}
char* ToHexa(char* lum)
{
	int r,d,num=0;
				int lenlum;
				for(lenlum=0; lum[lenlum]!='\0'; lenlum++)
				{}
				for(int i=0; lum[i]!='\0'; i++)
				{
					lenlum--;
					for(int k=0; lum[k]!='\0'; k++)
										{
									if(lum[k]<='7')
									d=8;
																}
								for(int k=0; lum[k]!='\0'; k++)
							{
									if(lum[k]>'7' && lum[k]<='9')
									d=10;
							}
								for(int k=0; lum[k]!='\0'; k++)
									{
											if(lum[k]>'9')
											d=16;

									}
								bool a=0;
															for(int i=0; lum[i]!='\0'; i++)
														{
															if(lum[i]!='0' && lum[i]!='1')
																a=1;
														}
														if(a==0)
														{
															d=2;
														}
					  if(lum[i] > '7' && lum[i]<='9')
			{
				 	r = (lum[i] - 48);
				 	num+=r*pow(d,lenlum);
			 }
			        if(lum[i] >= '0' && lum[i] <= '7')
			        {
			        	r = (lum[i] - 48);
			        	num+=r*pow(d,lenlum);
			        }

			        if(lum[i] >= 'a' && lum[i] <= 'f')
			        { r = (lum[i] - 87);
			        num+=r*pow(d,lenlum);}
			      else if(lum[i] >= 'A' && lum[i] <= 'F')
			      {    r =( lum[i] - 55);
					num+=r*pow(d,lenlum);}}
	int count=0,i=0,t=0;
	char* hexaa=new char[count];
	char* hexa=new char[count];
	char arr[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	while(num!=0)
	{
	hexaa[i]=arr[num%16];
	num/=16;
	i++;
	}
	i--;
	for(; i>=0; i--)
	{
		hexa[t]=hexaa[i];
		t++;
	}

	return hexa;
}
};


#endif /* CONVERSION_H_ */
