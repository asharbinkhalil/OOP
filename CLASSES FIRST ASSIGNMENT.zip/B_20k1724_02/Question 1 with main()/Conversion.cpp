/*
 * Conversion.cpp
 *
 *  Created on: Oct 13, 2021
 *      Author: asharbinkhalil
 */

#include "Conversion.h"
#include<iostream>
int main()
{
	char temp[16];
		cin>>temp;
Conversion c(temp);
c.setNumber(temp);

int B;

		int len;
			for( len=0; temp[len]; len++)
			{}
		int e=1;
		if(e)
		{
		bool a=0;
		for(int i=0; i<len; i++)
		{
			if(temp[i]!='0' && temp[i]!='1')
				a=1;
		}
		if(a==0)
		{
			cout<<"----------Number is binary----------\n\n";
			B=1;
		e=0;}
		}
		if(e)
		{
		char hex[]={'A','B','C','D','E','F','a','b','c','d','e','f'};
		for(int i=0; i<len; i++)
		{
			for(int j=0; j<12; j++)
			{
				if(temp[i]==hex[j] && e==1)
				{	e=0;
					B=2;
					cout<<"-----------Number is Hexa----------\n\n";
					break;
				}
			}
		}
		}
		if(e)
		{
		for(int i=0; i<len; i++)
		{
			if(temp[i]>'7' && e==1)
				{cout<<"----------Number is decimal:-----------\n\n";
						e=0;
						B=3;
				}}
		}
		if(e)
		{
			cout<<"-------Number is Octal---------- \n\n";
			B=4;
		}
		
switch(B)
{
case 1:
{
	cout<<c.ToDecimal(temp)<<"\ts DECIMAL VALUE\n";
	cout<<c.ToHexa(temp)<<"\tIS HEXA VALUE\n";
	cout<<c.ToOctal(temp)<< "\tIS OCTAL VALUE\n";
	break;
}
case 2:
{
	cout<<c.ToDecimal(temp)<<"\tIs DECIMAL VALUE\n";
		cout<<c.ToBinary(temp)<<"\tIS BINARY VALUE\n";
		cout<<c.ToOctal(temp)<< "\tIS OCTAL VALUE\n";
		break;
}
case 3:
{
	cout<<c.ToHexa(temp)<<"\tIS HEXA VALUE\n";
	cout<<c.ToBinary(temp)<<"\tIS BINARY VALUE\n";
	cout<<c.ToOctal(temp)<< "\tIS OCTAL VALUE\n";
		break;
}
case 4:
{
	cout<<c.ToDecimal(temp)<<"\tIs DECIMAL VALUE\n";
	cout<<c.ToBinary(temp)<<"\tIS BINARY VALUE\n";
	cout<<c.ToHexa(temp)<<"\tIS HEXA VALUE\n";
break;
}
}
}
