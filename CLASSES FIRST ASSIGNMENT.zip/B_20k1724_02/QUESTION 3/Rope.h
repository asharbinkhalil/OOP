/*
 * Rope.h
 *
 *  Created on: Oct 25, 2021
 *      Author: asharbinkhalil
 */

#ifndef ROPE_H_
#define ROPE_H_


class Rope {
private:
	int lenght;
	int thickness;
public:
	Rope()
	{

	}
	Rope(int l,int t):lenght(l),thickness(t){}
	int getlen() { return lenght; }
	int getthic() { return thickness; }
	void setlen(int l) { lenght = l; }
	void setthic(int t) { thickness = t; }
};


#endif /* ROPE_H_ */
