/*
 * Rotation.h
 *
 *  Created on: Oct 25, 2021
 *      Author: asharbinkhalil
 */

#ifndef ROTATION_H_
#define ROTATION_H_
#include"Pulley.h"
#include"Rope.h"
class Rotation
{
private:
	Pulley Pul;
	Rope Ro;
public:
	Rotation()
	{
	}
	Rotation(Pulley p,Rope r):Pul(p),Ro(r){}
	int g=Ro.getlen();
	int h=Pul.getrad();
	int i=Ro.getthic();
	int RotatingthePully(int h, int g, int i)
	{
		int count = 0;
		int l = 0;
		while (l < Ro.getlen()) {
			l += 22 / 7 * (Pul.getrad() * 2);
			count++;
			Pul.setrad(Pul.getrad()+Ro.getthic());
		}
		return count - 1;

	}
};
#endif /* ROTATION_H_ */
