/*
 * Pulley.h
 *
 *  Created on: Oct 25, 2021
 *      Author: asharbinkhalil
 */

#ifndef PULLEY_H_
#define PULLEY_H_

class Pulley {
private:
	int radius;
public:
	Pulley()
	{

	}
	Pulley(int r) :radius(r) {};
	void setrad(int r) {
		radius = r;
	}
	int getrad() {
		return radius;
	}
};

#endif /* PULLEY_H_ */
