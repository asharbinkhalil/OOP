/*
 * Rotation.cpp
 *
 *  Created on: Oct 25, 2021
 *      Author: asharbinkhalil
 */
#include"Pulley.h"
#include"Rope.h"
#include"Rotation.h"
#include<iostream>

using namespace std;

int main()
{
	int rad;
	int len;
	int thic;
	cout<<"Enter Radius:\n";
	cin>>rad;
	cout<<"Enter Length\n";
	cin>>len;
	cout<<"Enter Thickness\n";
	cin>>thic;
	Pulley a(rad);   //MAKING SEPARATE OBJECTS OF PULLEY AND ROPE
	Rope b(len, thic);
	Rotation c(a,b); //THEN PASSING THESE OBJECTS TO ROTAION CLASS
	cout<<c.RotatingthePully(rad, len ,thic);
}

