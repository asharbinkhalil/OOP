/*
 * Pulley.cpp
 *
 *  Created on: Oct 25, 2021
 *      Author: asharbinkhalil
 */

#include "Rotation.h"
#include"Pulley.h"
#include"Rope.h"
