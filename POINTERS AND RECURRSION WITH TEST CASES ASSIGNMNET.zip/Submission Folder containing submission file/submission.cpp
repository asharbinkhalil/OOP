/*



NAME :           ASHAR KHALIL
ROLL NUMBER:     20K1724
ASSIGNMENT NUMBER 1


*/

//Patterns are at start in this file , kindly comment them before executing.
//Pattern 1 , it has two functions;

/*


void PrintPattern1(int n, int k, char ch1, char ch2)
{
	if(n==k)
	{
	cout<<n;
	print(n,ch1);
	return;
	}
	else
	cout<<n;
	print(n,ch1);
	PrintPattern1(n+1,k,'@','+');	
	cout<<n;
	print(n,ch2);
}
void print(int k,char l)
{
	if(k==0)
	return;
	else
	{
		cout<<l;
		print(--k,l);
	}
}


//Pattern 2 it has three functions one patterprinting and two for spaces and stars printing




void PrintPattern2(char ch, int n1, int n2)
{int i;
	if(n1>n2)
	return;
	printspaces(ch,n1,i=n1,n2);
	PrintPattern2(ch,++n1,n2);
	
}
void printspaces(char ch,int n1,int i ,int n2)
{
		if(n1==n2)
	{
		printstars(ch,n1-i,n2);
	return;
	}
	else
	cout<<" ";
	printspaces(ch,++n1,i,n2);

}
void printstars(char ch, int n1,int n2)
{
	if(n1==n2)
	{
		cout<<"\n";
	return;
	}else
	cout<<ch;
	printstars(ch,++n1,n2);
}
//Pattern 3 it has 2 functions.



void printpattern(char ch,int n1,int n2){
	if(n1==n2)
	{
		printspaces(ch,1,2*n1-1,n2);
		return;
	}
	printspaces(ch,1,2*n1-1,n2);
	printpattern(ch,n1+1,n2);
	printspaces(ch,1,2*n1-1,n2);
}
void printspaces(char ch,int n1,int n,int n2)
{
	if(n1>4*n2-3){
		cout<<"\n";
		return;
	}
	if(n1==n||n1==4*n2-2-n){
		cout<<ch;
	}
	else{
		cout<<" ";
	}
	printspaces(ch,n1+1,n,n2);	
}

*/

int Strlen(char *s1)
{
	int count=0;
	for(int i=0; *(s1+i); i++)
	{
		count++;
	}
	return count;
}
char* Strcpy(char *s1,const char *s2)
{
s1=new char[100];
	for(int i=0; s2[i]!='\0'; i++)
	{
		s1[i]=s2[i];
	}
	return s1;
}
int StrCmp(const char* s1, const char *s2)
{
	int count=0,count1=0;
	for(int i=0; s1[i] || s2[i]; i++)
	{
		count+=s1[i];
		count1+=s2[i];
	}

	if(count==count1)
		return 0;
	if(count<count1)
		return -1;
	else
		return 1;
}
void StrTok(char* s1, const char s2, char**& listOfTokens , int& size)

{
	int count=0;
	listOfTokens=new char*[10];
	for(int i=0;i<10;i++)
	listOfTokens[i] = new char[5];
while (*s1 != '\0')
	{
		if (*s1==s2)
 		{
			count++;
			size=0;}
		if (*s1!=s2)
		{
		listOfTokens[count][size]=*s1;
		size++;}
	s1++;
	}
	count++;
	size=count;
}

bool StrFind(char* s1, char* s2, int*& listOfOccurrences, int& size)
{
	int v = 0;
	for (int l = 0; s2[l] != '\0'; l++) {
		v++;
	}

	listOfOccurrences = new int[20];
	int i, j;
	for (i = 0, j = 0; s1[i] != '\0'; i++)
	{

		if (*(s1+i) == *(s2+j))
			j++;
		else
		{
			j = 0;
			if (*(s1 + i) == *(s2 + j))
				j++;
		}
		if (j == v)
		{
			*(listOfOccurrences + size) = i - v + 1;
			size++;
		}
	}
	if (size != 0)
		return true;
	else
	{
		return false;
	}
}
bool StrSwapIn2DArray(char** s1, int numberOfRows, int swapIndex0, int swapIndex1)
{
	if (swapIndex0 >= numberOfRows || swapIndex1 >= numberOfRows || swapIndex0 < 0 || swapIndex1 < 0)
		return 0;
	for (int i = 0; *(*(s1 + i) + swapIndex0) == '\0' && *(*(s1 + i) + swapIndex0) == '\0'; i++)
	{
		char temp = s1[swapIndex0][i];
		s1[swapIndex0][i] = s1[swapIndex1][i];
		s1[swapIndex1][i] = temp;
	}
	return 1;
}

int find(int array[], int length, int target)
{

	if(length<0)
		return -1;
	else if(array[--length]==target)
		return length;
	else
		return find(array,length,target);
}
void replace(char* s1, char ch1, char ch2)
{
	
	if(*s1=='\0')
	return;
	if(*s1==ch1)
		*s1=ch2;
	return replace(s1+1,ch1,ch2);
}


